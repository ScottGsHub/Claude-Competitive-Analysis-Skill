# Quality Standards

## Purpose

This is the final quality gate before delivering a competitive analysis. Run through every item on this checklist.
A deliverable is not ready until all items pass.

This checklist is modeled on consulting firm QA standards used before client deliveries.

---

## Section 1 — Analytical Integrity

### Story & Structure
- [ ] A single, clear thesis sentence exists and was written before the deck was built
- [ ] Every slide in the main deck supports or reinforces the thesis
- [ ] Slides that do not support the thesis have been moved to the Appendix or cut
- [ ] The deck flows logically: Context → Findings → Synthesis → Recommendations
- [ ] The Executive Summary can stand alone as a complete summary of the analysis
- [ ] Recommendations are specific, actionable, and directly traceable to findings in the deck

### Slide Headlines
- [ ] Every content slide headline is a complete sentence stating the finding (not a topic label)
- [ ] No headline uses vague language: "significant," "large," "strong," "high" without a number
- [ ] The most important insight in the analysis appears on the Executive Summary slide

### Evidence
- [ ] Every quantitative claim (percentage, dollar figure, market share, score) has a source
- [ ] Sources are cited in speaker notes for all data slides
- [ ] Estimates are labeled as estimates (not presented as facts)
- [ ] No claim rests on a single Tier 5 (anecdotal) source alone
- [ ] Conflicting data sources are acknowledged, with reasoning for which was weighted more heavily

### Completeness
- [ ] All Tier 1 (direct) competitors have individual profile slides
- [ ] The Competitive Scorecard covers 8–12 criteria
- [ ] All scorecard scores have a confidence level (H/M/L) in the backup Excel file
- [ ] SWOT findings are all traceable to specific competitive findings — no generic bullets
- [ ] Porter's Five Forces assessment is included with ratings and explanation

---

## Section 2 — Data File Quality

- [ ] Excel backup file has all 8 required tabs (README through Source Log)
- [ ] Tab 2 (Competitor Profiles) has a row for every competitor mentioned in the deck
- [ ] Tab 3 (Scorecard) has a row for every criterion in the deck scorecard, with confidence levels
- [ ] Tab 8 (Source Log) has an entry for every URL and publication used
- [ ] Confidence levels (H/M/L) are fully populated — no blank confidence cells
- [ ] Color coding and formatting standards are applied (frozen headers, row colors, etc.)
- [ ] README tab is accurate and up to date

---

## Section 3 — Presentation Quality

### Visual Design
- [ ] A consistent color palette is applied throughout the deck
- [ ] Subject company is visually differentiated from competitors in all charts and tables
- [ ] No slide has more than 7 distinct visual elements
- [ ] Font sizes are consistent: headlines 24–32pt, body 14–18pt
- [ ] All charts have labeled axes with units
- [ ] All tables have clear column headers
- [ ] The competitive positioning map has labeled axes with a justification in speaker notes

### Slide Mechanics
- [ ] Cover slide has company name, market scope, date, and confidentiality label
- [ ] Appendix is clearly separated from the main deck with a divider slide
- [ ] Slide numbers are present on all slides except the cover
- [ ] Speaker notes exist for all data-heavy slides (charts, tables, heatmaps)
- [ ] No slide has visible formatting errors (text overflow, misaligned elements, broken charts)

---

## Section 4 — Consulting-Grade Presentation Standards

These are the higher-order standards that distinguish adequate work from excellent work.

### "The CEO Test"
Imagine the most skeptical, time-pressed executive reading this deck with no context.
- [ ] They can understand the key finding from the deck in under 2 minutes (Executive Summary does this)
- [ ] They can understand any single slide without reading the slides before or after it
- [ ] They know exactly what they're being asked to do by the last slide

### "The Deleted Data Test"
Remove all charts and tables from the deck. Reading only the slide headlines and bullets:
- [ ] The strategic narrative is still clear
- [ ] The recommendations still make sense
- [ ] The thesis is still visible

### "The Red Team Test"
For each key claim in the deck, ask: "How would the smartest skeptic poke holes in this?"
- [ ] Major potential counterarguments are addressed or at least acknowledged
- [ ] Data limitations are disclosed (not hidden)
- [ ] Recommendations do not overclaim certainty given the evidence quality

---

## Common Last-Mile Errors (Extra Check)

These errors commonly slip through. Double-check each:

- [ ] No competitor logos are too large, inconsistent in size, or missing
- [ ] Pricing data has a "captured date" — it goes stale within weeks
- [ ] Revenue figures for private companies are labeled as "estimates" not presented as facts
- [ ] The Source Log tab doesn't have broken or 404 URLs (spot-check a few)
- [ ] No confidential or sensitive information about the client company appears in sources cited
- [ ] The filename includes the company name and date (not "Untitled" or "Draft")
- [ ] The file is not excessively large (compress images if >25MB for a pptx)

---

## Delivery Package Checklist

Before presenting files to the user, confirm:

- [ ] `[Company]_Competitive_Analysis.pptx` — main deck
- [ ] `[Company]_Competitive_Data.xlsx` — backup data workbook
- [ ] (Optional) `[Company]_Sources.pdf` — source log export
- [ ] Files are named with the company name and a date or version indicator
- [ ] Files are in `/mnt/user-data/outputs/`
- [ ] A brief summary note for the user explains: what was built, key findings in 2–3 sentences,
  and any notable data gaps or limitations they should know about

---

## Quality Rating Scale

After running the checklist, assign an overall quality rating:

| Rating | Criteria |
|---|---|
| **Consulting-Grade** | All checklist items pass. CEO Test, Deleted Data Test, and Red Team Test all pass. |
| **Business-Ready** | All analytical and data items pass. Minor presentation issues acceptable. |
| **Draft Quality** | Core analysis complete but presentation polish or data documentation incomplete. |
| **Incomplete** | Major analytical gaps, missing sections, or key deliverables absent. Do not deliver. |

Only deliver files rated "Business-Ready" or above. Flag any "Consulting-Grade" gaps to the user as next steps.

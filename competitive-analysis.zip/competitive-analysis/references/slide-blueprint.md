# Slide Blueprint

## Purpose

This file defines the exact slide structure for a consulting-grade competitive analysis PowerPoint deck.
Every slide has a defined purpose, content requirement, and design guidance.

Read the pptx SKILL.md before building. This blueprint governs WHAT goes on each slide; the pptx skill
governs HOW to build it technically.

---

## Deck Architecture

| # | Slide Type | Title Format |
|---|---|---|
| 1 | Cover | Company Name + "Competitive Analysis" + Date |
| 2 | Executive Summary | Key findings — one per bullet, each a complete sentence insight |
| 3 | Scope & Methodology | What we analyzed, how, and key data limitations |
| 4 | Market Overview | Market size, growth rate, and key structural dynamics |
| 5 | Competitive Landscape Map | Positioning chart — all competitors placed visually |
| 6–N | Competitor Profiles | One slide per Tier 1 competitor |
| N+1 | Scorecard / Capability Matrix | Heatmap comparing all competitors |
| N+2 | Go-to-Market Comparison | Side-by-side GTM analysis |
| N+3 | SWOT | Subject company SWOT derived from competitive findings |
| N+4 | Porter's Five Forces | Market structure assessment |
| N+5 | Strategic Implications | "What this means for [Company]" — synthesis section |
| N+6 | Recommendations | 3–5 specific, prioritized actions |
| N+7 | Appendix Divider | "Backup & Supplementary Data" |
| N+8+ | Appendix Slides | Detailed data, source log, methodology notes |

---

## Slide-by-Slide Specifications

### Slide 1 — Cover
- **Headline:** "[Company Name] Competitive Analysis"
- **Subline:** Market segment being analyzed
- **Footer:** Prepared by / Date / Confidential label
- **Design:** Dark background, company colors if known, bold clean typography
- **No data content on this slide**

---

### Slide 2 — Executive Summary
- **Headline:** "Key Findings" or "What We Found" (as a sentence if possible)
- **Content:** 4–6 bullets. Each bullet = one complete finding sentence (not a topic).
  - BAD: "Product capabilities comparison"
  - GOOD: "Competitor A's product leads on integrations (4.8/5 vs. our 3.1/5), representing our most urgent gap"
- **Design:** Clean, minimal. Consider a bold call-out box for the single most critical finding.
- **Bottom note:** "See slides X–Y for supporting detail"

---

### Slide 3 — Scope & Methodology
- **Purpose:** Build credibility; set expectations; disclose limitations
- **Content:**
  - Scope box: Company analyzed, market defined, competitors included (and excluded, with reason)
  - Methodology box: Research types used, date range of research
  - Limitations box: Key data gaps or caveats (e.g., "Revenue figures for private companies are estimates")
- **Design:** 3-column layout or 3 distinct boxes

---

### Slide 4 — Market Overview
- **Headline:** State the most important thing about this market as a sentence
  - Example: "The $12B SMB HR tech market is growing 18% annually, driven by compliance complexity"
- **Content (choose 2–3 of):**
  - Market size (TAM/SAM) with growth rate — use a bar or line chart
  - Key market trends (3–4 bullets)
  - Customer segment breakdown
  - Geographic breakdown if relevant
- **Source labels:** Every data point must have a source citation

---

### Slide 5 — Competitive Landscape Map
- **Headline:** One sentence stating the insight from the map
- **Visual:** Bubble/scatter chart with:
  - Axes labeled and justified (explain WHY these axes were chosen in the speaker notes)
  - Each competitor as a labeled bubble
  - Subject company visually differentiated (color, border)
  - White space opportunity called out if present
- **Companion text box:** 3–4 bullet "what you're looking at" guide
- **Design:** High contrast, clear labels — this is often the most-referenced slide in the deck

---

### Slides 6–N — Individual Competitor Profiles
One slide per Tier 1 competitor (typically 3–6 competitors).

**Layout:** Two-column or structured grid

**Required content blocks:**
1. **Company snapshot bar** (top): Founded year | HQ | Employee count | Funding or Revenue | Website
2. **What they do** (1–2 sentences): Their value proposition in plain language
3. **Strengths vs. subject company**: 3–4 specific points
4. **Weaknesses vs. subject company**: 3–4 specific points
5. **Key strategic moves (last 12 months)**: Bulleted list with dates
6. **Threat level to subject company**: High / Medium / Low + one sentence rationale

**Speaker notes:** Include source citations for all claims on this slide

---

### Slide N+1 — Competitive Scorecard
- **Headline:** One sentence insight from the overall scorecard pattern
- **Visual:** Heatmap table
  - Rows = evaluation criteria (8–12)
  - Columns = subject company + all Tier 1 competitors
  - Cells = 1–5 score, color-coded (red = low, green = high)
  - Subject company column visually highlighted
  - Weighted score row at bottom (optional, if weights have been defined)
- **Callout:** Highlight 2–3 cells that represent the most strategically significant gaps or leads
- **Note:** Full scoring detail with confidence levels lives in the Excel backup file

---

### Slide N+2 — Go-to-Market Comparison
- **Headline:** One sentence insight about the GTM landscape
- **Visual:** Comparison table or side-by-side grid
  - Dimensions: Sales motion | Target segment | Pricing model | Key channels | Partnerships
  - One column per company
- **Insight callout box:** 2–3 strategic observations from the comparison

---

### Slide N+3 — SWOT Analysis
- **Headline:** "[Company]'s Competitive Position: [One-Sentence Assessment]"
- **Visual:** Classic 2x2 SWOT grid, full slide
- **Each cell:** 3–5 bullets, each traced to a specific competitive finding
- **Design note:** Internal (Strengths/Weaknesses) in one color family; External (Opportunities/Threats) in another
- **Footer:** "All SWOT elements derived from competitive research — see scorecard and competitor profiles"

---

### Slide N+4 — Porter's Five Forces
- **Headline:** "[Industry] market structure is [overall assessment: highly competitive / consolidating / etc.]"
- **Visual:** Five-forces diagram or table
  - Each force with a High/Medium/Low rating and 1–2 sentence explanation
- **Synthesis box:** 2–3 sentences on overall market attractiveness implications

---

### Slide N+5 — Strategic Implications
- **Headline:** "What This Means for [Company]"
- **Content:** 3–5 strategic implications, each structured as:
  - **[Bold label]:** One sentence implication. One sentence supporting evidence from the analysis.
- **This is the "so what" slide.** It bridges the data to the recommendations.
- **Design:** Can use icons, callout boxes, or arrow visuals to convey directionality

---

### Slide N+6 — Recommendations
- **Headline:** "Recommended Actions for [Company]"
- **Content:** 3–5 recommendations, each with:
  - **Action title** (bold, verb-led: "Accelerate," "Invest in," "Deprioritize")
  - **Rationale** (one sentence linking back to a specific finding)
  - **Priority** (Immediate / Near-term / Long-term) or (P1 / P2 / P3)
  - **Success metric** (what "done" looks like)
- **Design:** Use a prioritization visual (2x2 impact/effort, numbered list, or traffic light)
- **This is the most important slide in the deck.**

---

### Slide N+7 — Appendix Divider
- **Simple:** "Appendix & Supporting Data"
- **Subline:** "Detailed scoring, source log, and supplementary charts"
- **Design:** Dark background, clean

---

### Appendix Slides (N+8+)
Include as needed:
- Full scorecard with confidence ratings and source citations
- Detailed competitor profiles for Tier 2 competitors
- Source log (all URLs and publications used)
- Methodology notes
- Additional charts that didn't fit in the main narrative
- Glossary if technical terms were used

---

## Design Standards for the Full Deck

### Typography
- **Headline font:** Bold, 24–32pt
- **Body font:** Regular, 14–18pt
- **Captions/labels:** 10–12pt
- **Consistency:** Use maximum 2 font families across the entire deck

### Color Usage
- Subject company: Accent/highlight color throughout
- Positive/strength indicators: Green family
- Negative/threat indicators: Red/orange family
- Neutral/comparison data: Gray family
- Background: Dark for cover and dividers, light for content slides

### Slide Density Rule
**Maximum 7 elements per slide.** If a slide has more than 7 distinct visual elements, split it or move
content to the appendix. Cluttered slides lose executives instantly.

### Speaker Notes
Every data slide (charts, tables, maps) must have speaker notes with:
- Data source(s)
- Key talking points
- Any caveats or limitations about the data on this slide

---

## Common Mistakes to Avoid

- **Agenda slide as Slide 2:** Skip it. Executives don't need a table of contents for a 15-slide deck.
  Jump straight to findings.
- **Titles that name the topic, not the insight:** Every slide title should be a finding.
- **Oversized logos:** Company logos on competitor profiles should be small and consistent.
- **Charts without axes labels:** Label everything. Assume the reader may read the slides without you in the room.
- **Recommendations without owners or timelines:** A recommendation without "who does this by when" is a wish.

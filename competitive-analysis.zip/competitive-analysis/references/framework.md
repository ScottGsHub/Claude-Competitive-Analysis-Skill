# Analytical Framework Reference

## Overview

This file defines the analytical models to apply during a competitive analysis. Each model has a specific purpose,
construction method, and output format. Apply all core models. Apply optional models based on scope and decision context.

---

## Core Models (Always Apply)

### 1. Competitive Positioning Map

**Purpose:** Visually place all competitors in the market landscape to reveal white space, clustering, and the
subject company's relative position.

**Construction:**
- Choose two axes that are most strategically meaningful for THIS market (not generic axes).
  - Examples: Price vs. Breadth of Features | Enterprise Focus vs. SMB Focus | Speed of Delivery vs. Customization
  - Avoid generic axes like "Quality vs. Price" unless truly the right choice.
- Place each competitor as a bubble; bubble SIZE represents market share or revenue (relative).
- Color-code: Subject company = bold accent color. Tier 1 competitors = primary palette. Others = muted.
- Label white space explicitly with a text callout if strategically relevant.

**Output:** One chart image or slide visual + one-sentence insight headline.

**Insight template:**
*"[Subject company] occupies [position description], while the market clusters around [cluster description],
leaving [white space opportunity] unaddressed."*

---

### 2. Competitive Scorecard (Feature/Capability Matrix)

**Purpose:** Objectively compare all competitors across the dimensions that matter most to buyers.

**Construction:**
- Select 8–12 criteria. These should reflect the buying criteria of the target customer, not internal preferences.
  - Good sources for criteria: G2/Capterra review categories, sales objection logs, RFP requirements, analyst frameworks.
- Rate each competitor 1–5 on each criterion. Define the rating scale:
  - 1 = Does not offer / major gap
  - 2 = Basic / limited
  - 3 = Competitive / meets standard
  - 4 = Strong / above average
  - 5 = Best-in-class / market leading
- Sources for ratings: product pages, reviews, demos, analyst reports. Label each rating with a confidence level
  (H/M/L) based on evidence quality.
- Calculate a weighted total score if the client has stated which criteria matter most.

**Output:** Heatmap table (green = high, red = low) in both the deck and the Excel backup file.

**Insight template:**
*"[Subject company] leads on [criteria] but trails on [criteria], suggesting [strategic implication]."*

---

### 3. SWOT Analysis (Subject Company Only)

**Purpose:** Translate competitive findings into an internal/external assessment of the subject company.

**Important:** SWOT findings must be DERIVED from the competitive research — not brainstormed in a vacuum.
Every bullet must trace back to a specific competitive finding.

**Construction:**
- **Strengths:** What advantages does this company hold vs. competitors, as evidenced by the scorecard and positioning map?
- **Weaknesses:** Where does this company score below competitors on criteria that matter to buyers?
- **Opportunities:** What white spaces, unmet needs, or competitor vulnerabilities exist that this company could exploit?
- **Threats:** What competitor moves, market dynamics, or capability gaps pose risks?

**Output:** Classic 2x2 SWOT quad. Each cell: 3–5 bullets maximum. No fluff. Each bullet = one specific claim.

---

### 4. Porter's Five Forces Assessment

**Purpose:** Understand the structural forces shaping the competitive environment, not just the competitors themselves.

**Forces to Assess:**
1. **Rivalry Among Existing Competitors** — How intense? Fragmented or concentrated? Price-based or differentiated?
2. **Threat of New Entrants** — How high are barriers? Capital, regulatory, network effects, brand?
3. **Threat of Substitutes** — What non-obvious alternatives could pull customers away?
4. **Buyer Power** — How much leverage do customers have? Switching costs? Concentration?
5. **Supplier Power** — For this business model, who are the key suppliers and how much power do they hold?

**Rating Scale:** Rate each force: High / Medium / Low threat to profitability.

**Output:** Summary table with one paragraph of narrative interpretation. This is context, not the centerpiece —
keep it concise (one slide).

---

## Optional Models (Apply Based on Context)

### 5. Go-to-Market Comparison

**Use when:** The decision is about sales strategy, channel selection, or marketing investment.

**Dimensions:**
- Primary sales motion (direct enterprise, PLG, channel, self-serve)
- Target customer profile (ICP)
- Key marketing channels (content, paid, events, partnerships)
- Pricing model and average contract value (if knowable)
- Sales cycle length signals

**Output:** Side-by-side comparison table.

---

### 6. Funding & Financial Trajectory

**Use when:** The audience is investors, or the decision involves M&A, fundraising, or runway assessment.

**Dimensions (use what's available):**
- Total funding raised, most recent round, lead investors
- Revenue estimates or reported figures
- Growth rate signals (headcount growth as proxy if revenue is private)
- Burn rate signals (for startups)
- Valuation if known

**Output:** Timeline chart of funding rounds + summary table.

---

### 7. Customer Sentiment Analysis

**Use when:** The decision involves product strategy, customer retention, or pricing.

**Method:**
- Scrape or summarize G2, Capterra, Trustpilot, app store reviews for each competitor.
- Identify top 3 "love" themes and top 3 "hate" themes per competitor.
- Use a simple sentiment table: Competitor | Top Praises | Top Complaints | NPS/Rating

**Output:** Sentiment comparison table with highlighted patterns.

---

### 8. Strategic Move Timeline

**Use when:** Market is dynamic and recent moves signal future direction.

**Method:**
- Build a 12–24 month timeline of significant moves per competitor: product launches, acquisitions,
  exec hires, funding, partnership announcements, pricing changes.
- Look for patterns: Are they moving upmarket? Expanding internationally? Commoditizing?

**Output:** Horizontal timeline visual (one competitor per row).

---

## Analytical Anti-Patterns (Never Do These)

- **Do not rate competitors without citing evidence.** If you can't support a score, mark it "N/A" or "Insufficient data."
- **Do not include a competitor just because they're well-known.** Only include competitors relevant to the subject
  company's actual buyer set in the defined market segment.
- **Do not present a framework without an insight.** A SWOT with no conclusions is decoration.
- **Do not use "it depends" as a strategic recommendation.** Synthesize to a point of view.

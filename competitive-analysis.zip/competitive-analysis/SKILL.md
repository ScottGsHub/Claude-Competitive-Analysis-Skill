---
name: competitive-analysis
description: >
  Use this skill whenever a user wants to conduct, build, or output a competitive analysis, market landscape review,
  competitor benchmarking, strategic positioning assessment, or any comparison of a company against its competitors.
  Trigger whenever the user mentions "competitive analysis," "competitor research," "market landscape," "competitive
  positioning," "benchmark against competitors," "who are our competitors," "how do we stack up," "SWOT," "Porter's
  Five Forces," or any variation of understanding how a company compares to rivals in its market. This skill defines
  the consulting-grade framework, research methodology, and output standards. Always pair with the pptx skill and
  supporting reference files to produce a final deliverable.
---

# Competitive Analysis Skill

## Purpose

Produce a McKinsey/BCG-grade competitive analysis: structured, insight-driven, and decision-ready. The output is
not a data dump — it is a strategic narrative supported by evidence, culminating in a professional PowerPoint
deliverable with backup data files.

**Read the following reference files before starting:**

| Reference | When to Read |
|---|---|
| `references/framework.md` | Always — defines the analytical framework |
| `references/research-guide.md` | Before gathering data — defines what to find and where |
| `references/slide-blueprint.md` | Before building the deck — defines every slide |
| `references/data-tables.md` | Before building backup files — defines Excel/data structure |
| `references/quality-standards.md` | Before finalizing — defines pass/fail criteria |

---

## The Golden Rules

These rules govern every competitive analysis produced with this skill. They are non-negotiable.

### Rule 1: Insight Over Information
Every section must answer "So what?" Raw data with no interpretation is not acceptable. Every chart, table, and
finding must have a one-sentence "Insight Label" that tells the reader what to conclude.

### Rule 2: One Storyline
The entire analysis must support a single strategic narrative. Before building anything, define the thesis:
*"[Company] is [position] in a market where [key dynamic], meaning it must [strategic implication]."*
Every slide, chart, and data point should reinforce this thesis or be cut.

### Rule 3: Evidence-Backed Claims
No assertion without a source. Every claim must be tagged with a source type: Primary Research, Public Filing,
Industry Report, Web Search, or Expert Estimate. Estimates must be labeled as such.

### Rule 4: Decision-Ready Output
The final slide of every analysis must answer: "Given all of this, what are the 3 things leadership should do next?"
An analysis that doesn't end in a recommendation is incomplete.

### Rule 5: Pyramid Structure
Lead with the conclusion. Each section headline should be a complete sentence stating the finding, not a topic
label. BAD: "Revenue Comparison." GOOD: "Competitor A outpaces us on revenue 3:1, but our growth rate is 2x faster."

---

## Workflow

Follow this exact sequence. Do not skip steps.

### Phase 1: Define the Scope
Before any research, confirm with the user:
1. **Company**: Which company is being analyzed?
2. **Market**: What market/segment are we competing in?
3. **Competitors**: Who are the primary (direct) and secondary (adjacent) competitors?
4. **Decision**: What decision will this analysis inform? (e.g., pricing strategy, M&A, market entry, fundraising)
5. **Audience**: Who will read this? (Board, C-suite, investors, internal team)
6. **Depth**: Quick landscape (1–2 hours research) vs. deep dive (comprehensive)?

Capture answers and write a 2-sentence **Scope Statement** before proceeding.

### Phase 2: Research
Read `references/research-guide.md` for the full research protocol.

At minimum, gather data across these six dimensions for each competitor:

1. **Business Model** — How do they make money? Revenue streams, pricing model, unit economics if available.
2. **Market Position** — Market share, customer segments, geographic reach.
3. **Product/Service** — Feature set, differentiators, weaknesses, roadmap signals.
4. **Go-to-Market** — Sales motion, channels, partnerships, marketing strategy.
5. **Financials** — Revenue, growth rate, funding, profitability signals.
6. **Strategic Direction** — Recent moves, acquisitions, exec statements, job postings as signals.

Use web search aggressively. Check: company websites, press releases, Crunchbase, LinkedIn, G2/Capterra reviews,
earnings calls (for public companies), SEC filings, industry analyst reports, news coverage.

### Phase 3: Build the Analytical Framework
Read `references/framework.md` for full details.

Always apply at minimum:
- **Competitive Positioning Map** (2x2 or bubble chart) — places all competitors visually
- **Feature/Capability Scorecard** — rates each competitor on 8–12 criteria (1–5 scale)
- **SWOT Summary** — for the subject company only, informed by competitive findings
- **Porter's Five Forces** — quick assessment of market structure

### Phase 4: Synthesize to Insights
For each analytical output, write:
- **Headline Insight** (one bold sentence — the conclusion)
- **Supporting Evidence** (2–3 data points)
- **Strategic Implication** (what this means for the subject company)

### Phase 5: Build the Deliverable
Read `references/slide-blueprint.md` for the full slide-by-slide specification.
Read the pptx SKILL.md for technical construction guidance.

Build the PowerPoint first. Then build backup data files (Excel) per `references/data-tables.md`.

### Phase 6: Quality Check
Read `references/quality-standards.md` and run through the full checklist before presenting to the user.

---

## Output Files

| File | Tool | Purpose |
|---|---|---|
| `[Company]_Competitive_Analysis.pptx` | pptx skill | Primary deliverable |
| `[Company]_Competitive_Data.xlsx` | xlsx skill | Backup data & scoring |
| `[Company]_Sources.pdf` (optional) | pdf skill | Source log |

---

## Companion Skills Required

This skill does NOT work alone. Always use in combination with:
- **pptx skill** — for building the PowerPoint output
- **xlsx skill** — for building the data backup file
- **pdf skill** (optional) — for source documentation

---

## Tone & Voice

Write all slides and analysis in the voice of a senior management consultant:
- **Declarative, not descriptive.** State conclusions, not observations.
- **Precise, not vague.** Use numbers whenever possible. Avoid "significant," "large," "fast" without a figure.
- **Confident, not arrogant.** Acknowledge uncertainty where it exists; label estimates clearly.
- **Executive-facing.** No jargon, no acronyms without definition, no inside baseball.

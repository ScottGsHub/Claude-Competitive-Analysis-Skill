# Research Guide

## Purpose

This guide defines what to research, where to find it, how to evaluate source quality, and how to document findings
for a consulting-grade competitive analysis.

---

## Research Principles

### 1. Triangulate Every Major Claim
No single source is reliable enough to anchor a key finding. For every significant claim (market share, revenue,
product capability), find at least two independent sources. If they conflict, note the discrepancy and explain
which you weighted more heavily and why.

### 2. Distinguish Facts from Estimates
Label all data clearly:
- **Reported** — From an official source (SEC filing, press release, earnings call)
- **Analyst Estimate** — From a named research firm (Gartner, Forrester, IDC, etc.)
- **Derived** — Calculated by Claude from available data (explain the methodology)
- **Signal-Based** — Inferred from proxy data (e.g., headcount growth, job postings, web traffic)
- **Unverified** — Found in one source, could not triangulate

### 3. Recency Matters
Prioritize sources from the last 12 months. If using older data, flag it. Markets move fast — a 2-year-old
product comparison may be meaningless.

---

## Research Dimensions & Sources

For each competitor, research the following dimensions using the source types listed.

### Business Model & Revenue
| What to Find | Where to Look |
|---|---|
| Revenue or ARR | SEC filings (10-K, S-1), press releases, TechCrunch/Bloomberg, Crunchbase |
| Revenue model (subscription, usage, license) | Pricing pages, product docs, investor decks if public |
| Unit economics signals | S-1 filings, investor interviews, analyst reports |
| Funding history | Crunchbase, PitchBook (via press coverage), LinkedIn announcements |
| Customer count / ACV signals | Press releases, case studies, sales decks if leaked |

### Product & Capabilities
| What to Find | Where to Look |
|---|---|
| Feature set | Product website, documentation, demo videos, G2/Capterra listings |
| Recent product launches | Press releases, product blogs, release notes, GitHub (for dev tools) |
| Integrations & ecosystem | Marketplace pages, API docs, partner listings |
| Pricing tiers | Pricing pages (screenshot/note the date — prices change) |
| Customer reviews & pain points | G2, Capterra, Trustpilot, Reddit, App Store, Twitter/X |

### Market Position
| What to Find | Where to Look |
|---|---|
| Market share estimates | Gartner Magic Quadrant, Forrester Wave, IDC reports, analyst blogs |
| Customer segments / ICP | Case studies, "customers" page, sales messaging, job postings (AE targeting) |
| Geographic presence | Website, job postings, press releases, LinkedIn employee map |
| Key logos / marquee customers | Customers/case study pages, press releases |

### Go-to-Market
| What to Find | Where to Look |
|---|---|
| Sales motion | Job postings (SDR, AE, PLG roles), product-led signals (free tier, self-serve), channel partner pages |
| Marketing channels | Similarweb (traffic sources), LinkedIn ads, Google ads, content volume |
| Partnership strategy | Partner pages, press releases, reseller announcements |
| Events & PR activity | Conference sponsorships, press mentions, speaking slots |

### Leadership & Strategy
| What to Find | Where to Look |
|---|---|
| Executive team & backgrounds | LinkedIn, About pages, press bios |
| Strategic direction signals | CEO interviews, keynotes, investor letters, conference talks |
| Recent acquisitions | Crunchbase, press, SEC filings |
| Hiring patterns (growth signals) | LinkedIn, Greenhouse/Lever job boards |

---

## Source Quality Tiers

Rate each source before using it:

| Tier | Description | Examples |
|---|---|---|
| **Tier 1 — Primary** | Direct from the company or regulator | SEC filings, official press releases, earnings transcripts |
| **Tier 2 — Professional** | Credible third-party analysis | Gartner, Forrester, IDC, Bloomberg, WSJ, FT |
| **Tier 3 — Secondary** | Reputable journalism or aggregated data | TechCrunch, Business Insider, Crunchbase, G2 |
| **Tier 4 — Signal** | Inferred or proxy data | Job postings, web traffic, review volume, LinkedIn headcount |
| **Tier 5 — Anecdotal** | User-generated, unverified | Reddit, Twitter, individual blog posts |

Use Tier 5 only to surface themes, never to anchor factual claims.

---

## Research Documentation Format

For each competitor, document findings in this structure before building the analysis:

```
COMPETITOR: [Name]
Last Updated: [Date]

BUSINESS MODEL:
- Revenue model: [description] | Source: [Tier X — URL or description]
- Revenue estimate: [figure or range] | Source: [Tier X — URL]
- Funding: [total, last round, investors] | Source: [Tier X — URL]

PRODUCT:
- Key capabilities: [list] | Source: [Tier X]
- Recent launches: [list with dates] | Source: [Tier X]
- Pricing: [structure and tiers] | Source: [Tier X] | Captured: [date]
- G2/Capterra rating: [X.X/5, N reviews] | Top praises: [...] | Top complaints: [...]

MARKET POSITION:
- Estimated market share: [figure or signal] | Source: [Tier X]
- Key customer segments: [description] | Source: [Tier X]
- Notable customers: [list] | Source: [Tier X]

GO-TO-MARKET:
- Sales motion: [description] | Source: [Tier X]
- Primary marketing channels: [list] | Source: [Tier X]

STRATEGIC SIGNALS:
- Recent moves (last 12 months): [list with dates] | Source: [Tier X]
- Hiring patterns: [description] | Source: [Tier X]
- Leadership statements on strategy: [key quote or summary] | Source: [Tier X]

CONFIDENCE ASSESSMENT:
- Overall data quality for this competitor: [High / Medium / Low]
- Key gaps: [what we could not find]
```

---

## Research Anti-Patterns

- **Do not cite a competitor's own marketing copy as objective fact.** Their website says they're the "leader" —
  that's not a finding.
- **Do not rely solely on Wikipedia.** It's a starting point, never a source.
- **Do not confuse funding with revenue.** A company that raised $100M has not "made" $100M.
- **Do not skip the review sites.** G2 and Capterra are gold mines for understanding real customer pain points
  and satisfaction — this is often the most differentiated data in the analysis.
- **Do not forget job postings.** They are public signals of strategic direction. A competitor hiring 10 enterprise
  AEs is signaling a move upmarket.

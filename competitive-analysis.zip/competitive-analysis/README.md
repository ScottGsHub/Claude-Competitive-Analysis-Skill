# Competitive Analysis Skill Collection — README

## What This Is

This folder contains a complete skill collection for producing McKinsey/BCG-grade competitive analyses
with a professional PowerPoint deliverable and backup data files.

---

## File Structure

```
competitive-analysis/
├── SKILL.md                          ← Master skill file (start here)
└── references/
    ├── framework.md                  ← Analytical models (SWOT, Porter's, Scorecard, etc.)
    ├── research-guide.md             ← What to research, where, and how to document it
    ├── slide-blueprint.md            ← Every slide defined: purpose, content, design
    ├── data-tables.md                ← Excel backup workbook structure (8 tabs defined)
    └── quality-standards.md         ← Final QA checklist before delivery
```

---

## Companion Skills Required

This skill collection produces references and frameworks only. The actual file construction relies on
Anthropic's public skills. Ensure the following are available in your skill library:

| Skill | Purpose | Status |
|---|---|---|
| **pptx** | Build the PowerPoint presentation | Required |
| **xlsx** | Build the Excel data backup workbook | Required |
| **pdf** | (Optional) Export source log | Optional |
| **frontend-design** | (Optional) Build HTML dashboard version | Optional |

---

## Suggested Additional Skills to Complete the Collection

The following skill files are recommended as additions to make this a fully self-contained competitive
intelligence system. They are not included here but would significantly expand the capability.

### `market-sizing.md`
A dedicated reference for estimating market size (TAM/SAM/SOM) using bottom-up and top-down methodologies.
Should include: standard sizing frameworks, proxy data sources (industry reports, census data, Crunchbase),
calculation templates, and common mistakes to avoid. This fills the "Market Overview" slide with rigor.

### `customer-voice.md`
A protocol for systematically mining G2, Capterra, Trustpilot, and app store reviews to extract customer
sentiment themes. Should include: how to structure a review scraping approach, how to identify patterns,
how to quote responsibly without copyright issues, and how to present findings as insight not anecdote.
Powers the Customer Sentiment Analysis optional framework.

### `financial-signals.md`
A guide to estimating private company financials from proxy signals — headcount growth (LinkedIn),
job posting patterns, funding round sizing norms by stage, revenue multiples by sector, web traffic
(Similarweb) as revenue proxy. This is essential since most competitors in a typical B2B analysis are
private companies with no public financials.

### `gtm-intelligence.md`
A playbook for reverse-engineering a competitor's go-to-market strategy from public signals: job postings
(what AE profiles tell you about segment focus), marketing spend signals (SEMrush/Ahrefs), content strategy
analysis, partnership ecosystem mapping, and pricing page archaeology. Powers the GTM Comparison slide.

### `executive-narrative.md`
A writing guide for translating analytical findings into consultant-quality narrative prose. Should cover:
the Pyramid Principle (conclusion first), how to write insight headlines, how to write strategic implications,
how to write recommendations with teeth. This skill would improve the quality of all written output across
the analysis.

### `interview-guide.md`
A protocol for when primary research (customer or expert interviews) is part of the scope. Should include:
interview question frameworks by stakeholder type (customers, ex-employees, industry experts), how to
synthesize qualitative interview data, how to source expert interviews (LinkedIn, expert networks), and
how to cite interview-derived insights appropriately.

### `report-to-pptx-adapter.md`
A skill for converting a completed written competitive analysis (Word/PDF) into a PowerPoint deck. Useful
when the analysis was first drafted as a document and needs to be translated into a slide-ready format.
Should define the mapping logic from document sections to slide types.

---

## How the Skills Work Together — End-to-End Flow

```
User Request
    │
    ▼
competitive-analysis/SKILL.md
    │  Defines scope, workflow, golden rules
    │
    ├──► references/research-guide.md     (Phase 2: Research)
    │         + web_search tool
    │
    ├──► references/framework.md          (Phase 3: Analysis)
    │
    ├──► references/slide-blueprint.md    (Phase 5: Build deck)
    │         + pptx SKILL.md
    │
    ├──► references/data-tables.md        (Phase 5: Build backup)
    │         + xlsx SKILL.md
    │
    └──► references/quality-standards.md  (Phase 6: QA)
              │
              ▼
         Final Delivery:
         [Company]_Competitive_Analysis.pptx
         [Company]_Competitive_Data.xlsx
```

---

## Version History

| Version | Date | Notes |
|---|---|---|
| 1.0 | 2026-02-27 | Initial release |

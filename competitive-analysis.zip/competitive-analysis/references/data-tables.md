# Data Tables Reference

## Purpose

This file defines the structure of the Excel backup workbook that accompanies every competitive analysis deck.
The backup file serves as the evidentiary foundation — all data shown in the PowerPoint traces back to this workbook.

Read the xlsx SKILL.md before building this file.

---

## Workbook Structure

The Excel backup file should contain the following tabs, in this order:

| Tab # | Tab Name | Purpose |
|---|---|---|
| 1 | README | How to navigate the workbook |
| 2 | Competitor Profiles | Raw data for all competitors |
| 3 | Scorecard | Full capability scoring with confidence ratings |
| 4 | Positioning Data | X/Y coordinates and sizing for the positioning map |
| 5 | GTM Comparison | Go-to-market dimension data |
| 6 | Financials | Revenue, funding, growth data |
| 7 | Customer Sentiment | Review scores and theme summaries |
| 8 | Source Log | All sources used in the analysis |

---

## Tab Specifications

### Tab 1 — README
**Purpose:** Orientation for any reader who opens the file.

**Content:**
- Date prepared
- Analyst (Claude)
- Company analyzed
- Market scope
- Guide to each tab and what it contains
- Color coding legend used throughout the workbook
- Confidence rating definitions (H/M/L)

---

### Tab 2 — Competitor Profiles
**Purpose:** Master data table for all competitors.

**Columns:**
| Column | Description |
|---|---|
| Competitor Name | Full legal or trade name |
| Category | Tier 1 (direct), Tier 2 (adjacent), or Tier 3 (potential) |
| Founded | Year founded |
| HQ | City, Country |
| Employee Count | Latest estimate + source |
| Total Funding | USD, total raised |
| Last Round | Amount, type (Series A/B/etc.), date, lead investor |
| Revenue Estimate | USD or range, with confidence rating |
| Revenue Source | Source type and citation |
| Revenue Growth Signal | YoY growth % or signal description |
| Business Model | Revenue model description (SaaS/usage/license/etc.) |
| Target Segment | Primary customer type |
| Geographic Focus | Key regions served |
| Key Products | Primary product/service names |
| G2 Rating | X.X / 5 + number of reviews + date checked |
| Capterra Rating | X.X / 5 + number of reviews + date checked |
| Website | URL |
| Notes | Any relevant observations |

---

### Tab 3 — Scorecard
**Purpose:** Full capability comparison matrix with scoring detail.

**Structure:** Criteria in rows, competitors in columns.

**For each criterion:**
- Criterion name (row header)
- Weight (% of total, if weighted scoring is used)
- Score for each competitor (1–5)
- Confidence level for each score (H/M/L)
- Evidence note (brief description of what drove the score)
- Source citation

**Bottom rows:**
- Unweighted total score
- Weighted total score (if applicable)
- Rank

**Color coding:**
- 5 = Dark green
- 4 = Light green
- 3 = Yellow
- 2 = Orange
- 1 = Red
- N/A = Gray (with explanation in notes column)

---

### Tab 4 — Positioning Map Data
**Purpose:** Source data for the competitive positioning map in the deck.

**Columns:**
| Column | Description |
|---|---|
| Competitor Name | Name |
| X-Axis Value | Score or value on X axis (1–10 scale or actual metric) |
| Y-Axis Value | Score or value on Y axis |
| Bubble Size | Relative size metric (revenue, market share, customer count estimate) |
| X-Axis Basis | What data drove the X placement + source |
| Y-Axis Basis | What data drove the Y placement + source |
| Size Basis | What data drove the bubble size + source |

---

### Tab 5 — GTM Comparison
**Purpose:** Structured go-to-market comparison data.

**Columns:**
| Column | Description |
|---|---|
| Competitor Name | Name |
| Primary Sales Motion | Direct enterprise / Mid-market / SMB / PLG / Channel / Self-serve |
| Free Tier Available | Yes / No |
| Pricing Model | Subscription / Usage / Seat / Module / Custom |
| Pricing Transparency | Public pricing page: Yes/No |
| Entry Price Point | Lowest published tier (if available) |
| Enterprise Option | Yes / No / Unknown |
| Primary Marketing Channels | Top 2–3 channels observed |
| Key Partnerships | Notable partner types or named partners |
| Sales Cycle Indicator | Short (<30 days) / Medium (30–90) / Long (90+) / Unknown |
| Geographic Sales Presence | Regions with active sales teams |
| Source Notes | Sources for GTM observations |

---

### Tab 6 — Financials
**Purpose:** Financial trajectory and funding data for all competitors.

**Columns:**
| Column | Description |
|---|---|
| Competitor Name | Name |
| Revenue (Year) | Revenue figure or estimate for most recent period |
| Revenue Source | Tier 1–5 source description + citation |
| Revenue Confidence | H/M/L |
| YoY Growth | % growth estimate |
| Growth Source | Source description |
| Funding Round History | Chronological list (Round | Amount | Date | Lead) |
| Total Funding | Cumulative total raised |
| Last Valuation | If known, with date |
| Profitability Status | Profitable / Unprofitable / Unknown |
| Public/Private | Public (ticker) / Private |
| IPO/Exit Signals | Any signals of exit activity |

---

### Tab 7 — Customer Sentiment
**Purpose:** Aggregated review data and theme analysis.

**Columns:**
| Column | Description |
|---|---|
| Competitor Name | Name |
| G2 Rating | X.X / 5 |
| G2 Review Count | Number |
| G2 Top Praise Theme 1 | Theme description |
| G2 Top Praise Theme 2 | Theme description |
| G2 Top Praise Theme 3 | Theme description |
| G2 Top Complaint Theme 1 | Theme description |
| G2 Top Complaint Theme 2 | Theme description |
| G2 Top Complaint Theme 3 | Theme description |
| Capterra Rating | X.X / 5 |
| Capterra Review Count | Number |
| Other Review Source | Name and rating |
| Overall Sentiment | Positive / Mixed / Negative + brief characterization |
| Date Captured | When this data was pulled |

---

### Tab 8 — Source Log
**Purpose:** Full citation log for every source used in the analysis.

**Columns:**
| Column | Description |
|---|---|
| Source # | Sequential reference number (used throughout other tabs) |
| Source Tier | 1–5 per research guide definitions |
| Source Type | Website / Report / Filing / Review / Interview / etc. |
| Publisher / Author | Organization or person |
| Title / Description | Name of document, article, or page |
| URL | Full URL |
| Date Published | Publication date |
| Date Accessed | Date Claude retrieved this |
| Competitor(s) | Which competitor(s) this source informs |
| Key Data Points | What specific facts were drawn from this source |
| Confidence | H/M/L reliability assessment |

---

## Formatting Standards for the Workbook

- **Row 1 of each tab:** Bold column headers with a dark fill and white text
- **Alternating row colors:** Light gray / white for readability
- **Frozen top row on all tabs**
- **No merged cells** (merging breaks filtering)
- **All numeric columns right-aligned**
- **All text columns left-aligned**
- **Confidence ratings highlighted:** H = light green, M = light yellow, L = light red
- **Sheet tab colors:** Color-code tabs by type (blue = profiles, green = financial, orange = sources)

---

## Quality Check for the Data File

Before delivering, verify:
- [ ] Every competitor in the deck has a row in Tab 2
- [ ] Every score in the deck scorecard is backed by a row in Tab 3 with a confidence level
- [ ] Every data point in the deck with a statistic traces to a row in Tab 8
- [ ] All confidence ratings (H/M/L) are populated — no blanks
- [ ] Source Log (Tab 8) has an entry for every source referenced anywhere in the workbook
- [ ] README tab accurately describes the current state of the workbook

# Analytical Framework Reference

## Overview

This file defines the analytical models to apply during a competitive analysis. Each model has a specific purpose,
construction method, and output format. Apply all core models. Apply optional models based on scope and decision context.

---

## Core Models (Always Apply)

### 1. Competitive Positioning Map

**Purpose:** Visually place all competitors in the market landscape to reveal white space, clustering, and the
subject company's relative position.

**Construction:**
- Choose two axes that are most strategically meaningful for THIS market (not generic axes).
  - Examples: Price vs. Breadth of Features | Enterprise Focus vs. SMB Focus | Speed of Delivery vs. Customization
  - Avoid generic axes like "Quality vs. Price" unless truly the right choice.
- Place each competitor as a bubble; bubble SIZE represents market share or revenue (relative).
- Color-code: Subject company = bold accent color. Tier 1 competitors = primary palette. Others = muted.
- Label white space explicitly with a text callout if strategically relevant.

**Output:** One chart image or slide visual + one-sentence insight headline.

**Insight template:**
*"[Subject company] occupies [position description], while the market clusters around [cluster description],
leaving [white space opportunity] unaddressed."*

---

### 2. Competitive Scorecard (Feature/Capability Matrix)

**Purpose:** Objectively compare all competitors across the dimensions that matter most to buyers.

**Construction:**
- Select 8–12 criteria. These should reflect the buying criteria of the target customer, not internal preferences.
  - Good sources for criteria: G2/Capterra review categories, sales objection logs, RFP requirements, analyst frameworks.
- Rate each competitor 1–5 on each criterion. Define the rating scale:
  - 1 = Does not offer / major gap
  - 2 = Basic / limited
  - 3 = Competitive / meets standard
  - 4 = Strong / above average
  - 5 = Best-in-class / market leading
- Sources for ratings: product pages, reviews, demos, analyst reports. Label each rating with a confidence level
  (H/M/L) based on evidence quality.
- Calculate a weighted total score if the client has stated which criteria matter most.

**Output:** Heatmap table (green = high, red = low) in both the deck and the Excel backup file.

**Insight template:**
*"[Subject company] leads on [criteria] but trails on [criteria], suggesting [strategic implication]."*

---

### 3. SWOT Analysis (Subject Company Only)

**Purpose:** Translate competitive findings into an internal/external assessment of the subject company.

**Important:** SWOT findings must be DERIVED from the competitive research — not brainstormed in a vacuum.
Every bullet must trace back to a specific competitive finding.

**Construction:**
- **Strengths:** What advantages does this company hold vs. competitors, as evidenced by the scorecard and positioning map?
- **Weaknesses:** Where does this company score below competitors on criteria that matter to buyers?
- **Opportunities:** What white spaces, unmet needs, or competitor vulnerabilities exist that this company could exploit?
- **Threats:** What competitor moves, market dynamics, or capability gaps pose risks?

**Output:** Classic 2x2 SWOT quad. Each cell: 3–5 bullets maximum. No fluff. Each bullet = one specific claim.

---

### 4. Porter's Five Forces Assessment

**Purpose:** Understand the structural forces shaping the competitive environment, not just the competitors themselves.

**Forces to Assess:**
1. **Rivalry Among Existing Competitors** — How intense? Fragmented or concentrated? Price-based or differentiated?
2. **Threat of New Entrants** — How high are barriers? Capital, regulatory, network effects, brand?
3. **Threat of Substitutes** — What non-obvious alternatives could pull customers away?
4. **Buyer Power** — How much leverage do customers have? Switching costs? Concentration?
5. **Supplier Power** — For this business model, who are the key suppliers and how much power do they hold?

**Rating Scale:** Rate each force: High / Medium / Low threat to profitability.

**Output:** Summary table with one paragraph of narrative interpretation. Keep it concise (one slide).

---

## Optional Models (Apply Based on Context)

### 5. Radar Chart / Brand Perception Map

**Use when:** You want an executive-facing visual that tells the competitive story at a glance, or when the
scorecard heatmap feels too dense for the audience.

**Construction:**
- Select 6–8 dimensions (fewer than the scorecard — these should be the most strategically important).
- Plot each competitor as a separate line on the radar. Subject company should be bold/filled.
- Each axis runs from 0 (center) to 5 (outer edge).
- Overlapping lines reveal where competitors cluster; gaps reveal differentiation opportunities.

**When to use instead of the heatmap:** When the audience is a board or executive team who needs a quick
visual rather than a detailed table. The radar chart sacrifices granularity for impact.

**Output:** One radar chart + insight headline. Full scorecard heatmap moves to the appendix if radar is used on the main deck.

---

### 6. BCG Growth-Share Matrix

**Use when:** The subject company or its competitors have multiple products or business units, and you need
to assess portfolio investment priorities. Also useful when the decision involves M&A or product line strategy.

**Construction:**
- X-axis: Relative market share (high = right). Y-axis: Market growth rate (high = top).
- Four quadrants:
  - **Stars** (high growth, high share): Invest and protect
  - **Cash Cows** (low growth, high share): Harvest to fund others
  - **Question Marks** (high growth, low share): Decide to invest or exit
  - **Dogs** (low growth, low share): Consider divesting
- Plot each competitor's primary product/business as a bubble. Bubble size = revenue or funding.
- Subject company's position should be highlighted distinctly.

**Strategic use in competitive analysis:** Reveals where competitors are likely to invest next (Question Marks
with strong funding = likely Stars soon) and where they may be harvesting (Cash Cows often signal that a segment
is commoditizing — a potential opening).

**Output:** BCG matrix chart + brief narrative on competitor portfolio postures and what they signal.

---

### 7. PESTLE Analysis

**Use when:** The decision involves market entry, geographic expansion, a highly regulated industry, or when
macro trends are a primary driver of market change. PESTLE provides environmental context that Porter's Five
Forces and the scorecard don't cover.

**Dimensions:**
- **Political** — Government stability, trade policy, political risk, regulatory stance toward the industry
- **Economic** — Growth rates, inflation, interest rates, consumer spending, recession risk
- **Social** — Demographics, cultural shifts, workforce trends, changing customer values
- **Technological** — Emerging technologies, R&D intensity, automation, AI disruption, infrastructure
- **Legal** — Industry-specific regulations, compliance requirements, IP landscape, labor law
- **Environmental** — Sustainability pressures, climate regulation, ESG expectations, supply chain risk

**Rating approach:** For each dimension, assess: Is this a tailwind, headwind, or neutral for the subject company
relative to competitors? A factor that affects everyone equally is less interesting than one that creates
asymmetric advantage or disadvantage.

**Output:** PESTLE summary table — one row per dimension: Factor | Current State | Trend Direction |
Impact on Subject Company | Relative to Competitors. One slide, kept concise.

**Pairing note:** Run PESTLE first to set macro context, then Porter's for market structure, then the scorecard
for competitor-specific detail. This sequence builds the analytical narrative logically.

---

### 8. Business Model Canvas (Competitor Profiling)

**Use when:** You need to deeply understand how a competitor makes money — not just what they sell, but the
full system of how they create, deliver, and capture value. Especially useful for competitors with platform
plays, marketplace models, or non-obvious revenue structures.

**Nine dimensions to map for each competitor:**
1. **Value Proposition** — What problem do they solve? What's their core promise?
2. **Customer Segments** — Who do they serve? Primary and secondary segments?
3. **Channels** — How do they reach and deliver to customers? Direct, partner, digital?
4. **Customer Relationships** — How do they acquire and retain? Self-serve, high-touch, community?
5. **Revenue Streams** — How do they charge? Subscription, usage, licensing, freemium, marketplace take rate?
6. **Key Resources** — What do they need to operate? Technology, talent, data, IP, brand?
7. **Key Activities** — What must they do well? Product development, sales, logistics, platform management?
8. **Key Partnerships** — Who do they depend on? Resellers, technology partners, suppliers?
9. **Cost Structure** — Where does the money go? Fixed vs. variable? What are the biggest cost drivers?

**Output:** Full Business Model Canvas for each Tier 1 competitor lives in the appendix. The main deck surfaces
only the 2–3 most strategically significant business model differences from the subject company.

---

### 9. Crossing the Chasm / Technology Adoption Positioning

**Use when:** The market is a technology or SaaS market where adoption stage is strategically meaningful.
Particularly useful when the question is "who will dominate the mainstream market?" or "are we at risk of
being leapfrogged?"

**The Adoption Curve Stages:**
- **Innovators** (~2.5%): Tech enthusiasts; buy for the love of new technology
- **Early Adopters** (~13.5%): Visionaries; buy for competitive advantage, tolerant of rough edges
- **Early Majority** (~34%): Pragmatists; need proven solutions and peer references — this is the chasm
- **Late Majority** (~34%): Conservatives; buy when it becomes the de facto standard
- **Laggards** (~16%): Skeptics; buy only when forced

**Placement signals:**
- Still in early market: PLG motion, developer-focused, rough UX acceptable, pricing experimental
- Crossing the chasm: Enterprise sales team being built, case studies with mainstream logos, compliance features appearing
- Mainstream: Broad channel partnerships, analyst recognition (Gartner/Forrester), pricing standardized

**Output:** Adoption curve diagram with competitor placements + one paragraph on strategic implication.
A competitor about to cross the chasm is a high-priority threat signal — flag it prominently.

---

### 10. Go-to-Market Comparison

**Use when:** The decision is about sales strategy, channel selection, or marketing investment.

**Dimensions:**
- Primary sales motion (direct enterprise, PLG, channel, self-serve)
- Target customer profile (ICP)
- Key marketing channels (content, paid, events, partnerships)
- Pricing model and average contract value (if knowable)
- Sales cycle length signals

**Output:** Side-by-side comparison table.

---

### 11. Funding & Financial Trajectory

**Use when:** The audience is investors, or the decision involves M&A, fundraising, or runway assessment.

**Dimensions (use what's available):**
- Total funding raised, most recent round, lead investors
- Revenue estimates or reported figures
- Growth rate signals (headcount growth as proxy if revenue is private)
- Burn rate signals (for startups)
- Valuation if known

**Output:** Timeline chart of funding rounds + summary table.

---

### 12. Customer Sentiment Analysis

**Use when:** The decision involves product strategy, customer retention, or pricing.

**Method:**
- Summarize G2, Capterra, Trustpilot, and app store reviews for each competitor.
- Identify top 3 praise themes and top 3 complaint themes per competitor.
- Use a simple sentiment table: Competitor | Top Praises | Top Complaints | Rating

**Output:** Sentiment comparison table with highlighted patterns.

---

### 13. Strategic Move Timeline

**Use when:** The market is dynamic and recent competitor moves signal future direction.

**Method:**
- Build a 12–24 month timeline of significant moves per competitor: product launches, acquisitions,
  exec hires, funding, partnership announcements, pricing changes.
- Look for directional patterns: moving upmarket? Expanding geographically? Commoditizing a segment?

**Output:** Horizontal timeline visual (one competitor per row).

---

### 14. Win/Loss Analysis

**Use when:** You have access to customers, ex-customers, or prospects who have evaluated the subject
company against competitors. This is primary research — the richest competitive signal available.

**Interview types:**
- **Win interviews:** Customers who chose the subject company. What alternatives did you consider? What tipped the decision?
- **Loss interviews:** Prospects who chose a competitor. Where did the subject company fall short? What did the competitor do better?
- **Evaluator interviews:** People who evaluated but haven't bought from anyone yet.

**Key questions for all interviews:**
1. What problem were you trying to solve?
2. Which alternatives did you seriously consider?
3. What were the top 3 factors in your decision?
4. Where did each option fall short?
5. What would have changed your decision?

**Synthesis:** Tally win/loss reasons across interviews. A reason appearing in 3+ interviews is a signal.
A reason appearing once is anecdote — note it but don't anchor on it.

**Output:** Win/Loss summary table: Top Win Reasons | Top Loss Reasons | Most Common Comparison Points.
One slide in the main deck; full interview summaries in the appendix.

**Note:** If primary interview data is unavailable, G2/Capterra review text is a reasonable substitute —
customers frequently self-report comparative reasoning in written reviews.

---

## Analytical Anti-Patterns (Never Do These)

- **Do not rate competitors without citing evidence.** If you can't support a score, mark it "N/A" or "Insufficient data."
- **Do not include a competitor just because they're well-known.** Only include competitors relevant to the subject
  company's actual buyer set in the defined market segment.
- **Do not present a framework without an insight.** A SWOT with no conclusions is decoration.
- **Do not use "it depends" as a strategic recommendation.** Synthesize to a point of view.
- **Do not apply every framework to every analysis.** Choose the ones that serve the specific decision.
  More frameworks does not equal better analysis.
